<!DOCTYPE HTML>
<html lang="en">

    <?php require_once 'parts/head.php'; ?>

    <body>
        <div class="main_container">

            {{CONTENT}}

            <?php require_once 'parts/footer.php'; ?>
		</div>
    </body>

</html>

